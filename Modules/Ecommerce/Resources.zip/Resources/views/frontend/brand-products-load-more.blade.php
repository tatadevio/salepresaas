@foreach($products as $product)
@include('ecommerce::frontend.includes.product-template')
@endforeach